# To-Do List TDD (Java + JUnit 5)

Projeto simples para praticar Test-Driven Development (TDD) com uma lista de tarefas em memória.

## Requisitos cobertos
- Adicionar tarefa (nome + descrição)
- Marcar como **concluída** (DONE)
- Marcar como **em andamento** (IN_PROGRESS)
- Editar **nome** e **descrição**
- Excluir tarefa
- Listar tarefas

## Como rodar
1. Instale o Java 17+ e Maven.
2. No terminal, dentro da pasta do projeto:
   ```bash
   mvn test
   ```
3. Todos os testes devem passar ✅.

## Estrutura
```
todo-tdd/
├─ pom.xml
├─ src/
   ├─ main/java/com/example/todo/
   │  ├─ TaskStatus.java
   │  ├─ Task.java
   │  └─ TaskService.java
   └─ test/java/com/example/todo/
      └─ TaskServiceTest.java
```
