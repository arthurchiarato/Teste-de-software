package com.example.todo;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

public class TaskService {

    private final Map<Long, Task> store = new LinkedHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public Task addTask(String name, String description) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome da tarefa não pode ser vazio.");
        }
        long id = seq.getAndIncrement();
        Task t = new Task(id, name.trim(), description == null ? "" : description.trim(), TaskStatus.TODO);
        store.put(id, t);
        return t;
    }

    public Task markAsDone(Long id) {
        Task t = getRequired(id);
        t.setStatus(TaskStatus.DONE);
        return t;
    }

    public Task markInProgress(Long id) {
        Task t = getRequired(id);
        t.setStatus(TaskStatus.IN_PROGRESS);
        return t;
    }

    public Task editTask(Long id, String newName, String newDescription) {
        Task t = getRequired(id);
        if (newName == null || newName.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome da tarefa não pode ser vazio.");
        }
        t.setName(newName.trim());
        t.setDescription(newDescription == null ? "" : newDescription.trim());
        return t;
    }

    public void deleteTask(Long id) {
        getRequired(id);
        store.remove(id);
    }

    public List<Task> listTasks() {
        return Collections.unmodifiableList(new ArrayList<>(store.values()));
    }

    private Task getRequired(Long id) {
        Task t = store.get(id);
        if (t == null) {
            throw new IllegalArgumentException("Tarefa não encontrada: id=" + id);
        }
        return t;
    }
}
