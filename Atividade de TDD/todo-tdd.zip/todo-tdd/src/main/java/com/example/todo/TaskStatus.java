package com.example.todo;

public enum TaskStatus {
    TODO, IN_PROGRESS, DONE
}
