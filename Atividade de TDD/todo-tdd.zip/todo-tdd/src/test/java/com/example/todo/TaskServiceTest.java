package com.example.todo;

import org.junit.jupiter.api.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    @DisplayName("Adicionar tarefa com nome e descrição")
    void addTask_shouldCreateTaskWithAutoIdAndDefaultStatusTODO() {
        Task t = service.addTask("Estudar TDD", "Ler sobre Red-Green-Refactor");

        assertNotNull(t.getId());
        assertEquals("Estudar TDD", t.getName());
        assertEquals("Ler sobre Red-Green-Refactor", t.getDescription());
        assertEquals(TaskStatus.TODO, t.getStatus());

        List<Task> all = service.listTasks();
        assertEquals(1, all.size());
        assertEquals(t.getId(), all.get(0).getId());
    }

    @Test
    @DisplayName("Não permitir adicionar tarefa com nome em branco")
    void addTask_shouldRejectBlankName() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.addTask("   ", "desc"));
        assertTrue(ex.getMessage().toLowerCase().contains("nome"));
    }

    @Test
    @DisplayName("Marcar tarefa como concluída")
    void markAsDone_shouldSetStatusDONE() {
        Task t = service.addTask("Praticar testes", "Escrever asserts");
        Task updated = service.markAsDone(t.getId());

        assertEquals(TaskStatus.DONE, updated.getStatus());
    }

    @Test
    @DisplayName("Marcar tarefa como em andamento")
    void markInProgress_shouldSetStatusIN_PROGRESS() {
        Task t = service.addTask("Implementar serviço", "Service + Map");
        Task updated = service.markInProgress(t.getId());

        assertEquals(TaskStatus.IN_PROGRESS, updated.getStatus());
    }

    @Test
    @DisplayName("Editar nome e descrição de uma tarefa existente")
    void editTask_shouldUpdateNameAndDescription() {
        Task t = service.addTask("Antigo", "Desc antiga");
        Task edited = service.editTask(t.getId(), "Novo", "Desc nova");

        assertEquals("Novo", edited.getName());
        assertEquals("Desc nova", edited.getDescription());
    }

    @Test
    @DisplayName("Excluir tarefa pelo id")
    void deleteTask_shouldRemoveTask() {
        Task t1 = service.addTask("A", "a");
        Task t2 = service.addTask("B", "b");

        service.deleteTask(t1.getId());

        List<Task> remaining = service.listTasks();
        assertEquals(1, remaining.size());
        assertEquals(t2.getId(), remaining.get(0).getId());
    }

    @Test
    @DisplayName("Operações com id inexistente devem falhar claramente")
    void operationsWithMissingId_shouldThrow() {
        long unknownId = 9999L;
        assertThrows(IllegalArgumentException.class, () -> service.markAsDone(unknownId));
        assertThrows(IllegalArgumentException.class, () -> service.markInProgress(unknownId));
        assertThrows(IllegalArgumentException.class, () -> service.editTask(unknownId, "x", "y"));
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(unknownId));
    }

    @Test
    @DisplayName("Listar tarefas retorna cópia imutável (não deixa corromper estado)")
    void listTasks_shouldReturnImmutableCopy() {
        service.addTask("X", "Y");
        List<Task> list = service.listTasks();
        assertThrows(UnsupportedOperationException.class, () -> list.add(new Task()));
    }
}
